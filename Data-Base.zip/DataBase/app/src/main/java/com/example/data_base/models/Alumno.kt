package com.example.data_base.models


data class Alumno(
    val nombre: String="",
    val grupo: String="",
    val codigo:Int=0,

    )//fin del la clase
