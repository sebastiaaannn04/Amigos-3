package com.example.data_base.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data_base.models.AlumnosViewModel
import com.example.data_base.screens.AddScreen
import com.example.data_base.screens.AppAlumnos
import com.example.data_base.screens.LoginScreen
import com.example.data_base.screens.MainViewModel

@Composable
fun AppNavigation (
    pasa : Boolean,
    onClick : ()-> Unit,
    mainViewModel: MainViewModel
){
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = AppScreens.LoginScreen.route
    ){

        composable(route = AppScreens.LoginScreen.route) {

           if (pasa) {
                LaunchedEffect(key1 = Unit) {
                    navController.navigate(AppScreens.Home.route) {
                        popUpTo(AppScreens.LoginScreen.route) {
                            inclusive = true
                        }
                    }
                }
            } else {
                LoginScreen(
                    navController,
                    isLoading = false,
                    onLoginClick = onClick,
                )
            }
        }
        composable(route = AppScreens.Home.route){ AppAlumnos(navController, AlumnosViewModel()) }

        composable(route = AppScreens.AddScreen.route){ AddScreen(navController, ) }
    }
}