package com.example.data_base

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import com.example.data_base.models.AlumnosViewModel
import com.example.data_base.navigation.AppNavigation
import com.example.data_base.screens.LoginScreen
import com.example.data_base.screens.MainViewModel
import com.example.data_base.ui.theme.DataBaseTheme
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.tasks.Task


class MainActivity : ComponentActivity() {
    val viewModel by viewModels<AlumnosViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: MainViewModel by viewModels()
            //var isLoading by remember{ mutableStateOf(false) }
            val isLoading by viewModel.isLoading().observeAsState(false)

            val pasa by viewModel.pasa().observeAsState(false)
            DataBaseTheme() {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    AppNavigation(
                        pasa, onClick = { viewModel.LoginWithGoogle(this@MainActivity) }, viewModel
                    )

                }
            }
        }
    }

    override fun onActivityResult(
        requestCode: Int, resultCode: Int, data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        val viewModel: MainViewModel by viewModels()

        if (requestCode == 1) {

            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            viewModel.finishLogin(task)
        }
    }


}
