package com.example.data_base.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.data_base.models.Alumno
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialAcaffoldPaddingParameter", "UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreen(navController: NavHostController) {
    Scaffold(
        topBar = { TopAppBar {} },
        floatingActionButton = {
            FloatingActionButton(modifier = Modifier.size(32.dp),
                onClick = { /*TODO*/ }) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Agregar",
                    tint = Color.White
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ){
        BodyContent()
    }
}


@Composable
fun BodyContent() {
    var Alnombre by remember { mutableStateOf("") }
    var Algrupo by remember { mutableStateOf("") }
    var Alcodigo by remember { mutableStateOf("") }
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 16.dp)
        ) {

            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = Alnombre,
                onValueChange = { Alnombre = it },
                label = { Text(text = "Nombre") },
            )

            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = Algrupo,
                onValueChange = { Algrupo = it },
                label = { Text(text = "Grupo") },
            )

            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = Alcodigo,
                onValueChange = { Alcodigo = it },
                label = { Text(text = "Codigo") },
            )


            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = {
                val alumno = Alumno(Alnombre, Algrupo, Alcodigo.toInt())
                Firebase.firestore.collection("alumnos").add(alumno)
                    },
            modifier=Modifier
                .align(Alignment.CenterHorizontally)
                .padding(vertical = 8.dp)
                .fillMaxWidth()
            ){
                Text(text = "Add Alumno")
            }


        }
    }
}
